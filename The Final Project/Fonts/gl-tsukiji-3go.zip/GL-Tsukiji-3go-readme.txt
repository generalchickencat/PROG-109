GL-Tsukiji-3go: multibyte Japanese HIRAGANA/KATAKANA font

(C)2008-2018 Gutenberg Labo (http://gutenberg.osdn.jp/), All rights reserved.

- GL-Tsukiji-3go License
  These fonts are free softwares.
  Unlimited permission is granted to use, copy, and distribute it, with or without modification, either commercially and noncommercially.
  THESE FONTS ARE PROVIDED "AS IS" WITHOUT WARRANTY.

- About GL-Tsukiji-3go font
  GL-Tsukiji is the HIRAGANA and KATAKANA fonts from typeface of the Tokyo Tsukiji Kappan, Japanese type foundry in Meiji period (1868-1912).
  GL-Tsukiji-3go supports... U+0020, U+3000, U+3005, U+3006, U+303B, U+3041-U+3096, U+3099-U+309F, U+30A1-U+30FF, U+31F0-U+31FF.
  This font also supports basic Latin characters from "Manuel Typographique" Pierre-Simon Fournier, but they are only for Kana character input support.
